STAR PUBLIC SCHOOL WEBSITE
Open index.html in a browser.

This version includes the supplied official school logo and CEO photo.
Files:
- index.html
- school-logo.jpg
- ceo-hammad-nazir.png
